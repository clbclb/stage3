#include "pvp_game.h"

PVPGame::PVPGame(QWidget *parent):Widget(parent)
{

}

PVPGame::~PVPGame()
{

}
