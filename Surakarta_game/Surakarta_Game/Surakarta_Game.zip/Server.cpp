#include<Server.h>
#include<networkdata.h>

Server::Server(QWidget *parent)
    :QWidget{parent}
{
    _white=NULL;
    _black=NULL;
    server=new NetworkServer(this);
    server->listen(QHostAddress::Any,1);
    connect(server, &NetworkServer::newConnection, this, &Server::slotNewConnection);
    connect(server, &NetworkServer::receive, this, &Server::receiveData);
}

Server::~Server(){

}

void Server::slotNewConnection(){
    QMessageBox::about(this,"ooo","congratulations you build a new connection");
}

void Server::receiveData(QTcpSocket* client, NetworkData data){
    QMessageBox::about(this,"ooo","congratulations you receive data");
    if(data.data3!=room_id)return;
    if(data.op==OPCODE::READY_OP){
        if(_white&&_black)return;
        if(_white==NULL&&_black==NULL){
            if(data.data2=="WHITE"){
                _white=client;
                _white_name=data.data1;
            }
            else if(data.data2=="BLACK"){
                _black=client;
                _black_name=data.data1;
            }
            else{
                return;
            }
        }
        else{
            if(_white==NULL){
                _white=client;
                _white_name=data.data1;
            }
            else{
                _black=client;
                _black_name=data.data1;
            }
            server->send(_white,NetworkData(OPCODE::READY_OP,_black_name,"BLACK",room_id));
            server->send(_black,NetworkData(OPCODE::READY_OP,_white_name,"WHITE",room_id));
        }
    }
}
