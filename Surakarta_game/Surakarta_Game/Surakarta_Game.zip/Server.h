#ifndef SERVER_H
#define SERVER_H

#include<widget.h>
#include<networkserver.h>
#include<networksocket.h>

class Server : public QWidget
{
    Q_OBJECT
public:
    NetworkServer* server;
    explicit Server(QWidget *parent = nullptr);
    ~Server();
    QTcpSocket *_white,*_black;
    QString _white_name,_black_name;
    const QString room_id="1";

public slots:
    void receiveData(QTcpSocket* client, NetworkData data);
    void slotNewConnection();
};

#endif // SERVER_H
