#ifndef CLIENT_H
#define CLIENT_H

#include<widget.h>
#include<networksocket.h>

class Client : public QWidget
{
   Q_OBJECT
public:
   NetworkSocket *socket;
   explicit Client(QWidget *parent = nullptr);
    ~Client();
   bool isblack,your_turn;

public slots:
    void receiveData(NetworkData data);
};

#endif // CLIENT_H
