#include "Client.h"
#include "networkdata.h"
#include<QMessageBox>
Client::Client(QWidget *parent)
    :QWidget{parent}
{
    QMessageBox::StandardButton ret;
    ret=QMessageBox::question(NULL,"white or black", "你是否想成为黑方（先手）");
    bool black=0;
    if(ret==QMessageBox::Yes)black=1;
    socket = new NetworkSocket(new QTcpSocket(),this);
    connect(socket,&NetworkSocket::receive,this,&Client::receiveData);
    socket->hello("127.0.0.1",1);
    if(black){
        socket->send(NetworkData(OPCODE::READY_OP,"A","BLACK","1"));
        // QMessageBox::about(this,"send","send ready op");
    }
    else{
        socket->send(NetworkData(OPCODE::READY_OP,"A","WHITE","1"));
        // QMessageBox::about(this,"send","send ready op");
    }

}

Client::~Client(){

}

void Client::receiveData(NetworkData data){
    if(data.op==OPCODE::READY_OP){
        if(data.data2=="BLACK"){
            isblack=0;
            your_turn=0;
            QMessageBox::about(this,"color","you become white player");
        }
        else{
            isblack=1;
            your_turn=1;
            QMessageBox::about(this,"color","you become white player");
        }
    }
}
